
package com.touslesmatchs.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION = 105;
    private static final String HOME =
        "https://www.touslesmatchs.com/app.html?source=android&app=goal05&native=106";

    private WebView webView;
    private String pendingEmail;
    private String pendingSession;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setUserAgentString(
            settings.getUserAgentString() + " TousLesMatchsAndroid/1.0.6"
        );

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                    "window.__TLM_NATIVE_ANDROID=true;" +
                    "window.dispatchEvent(new Event('tlm-native-ready'));",
                    null
                );
            }
        });

        webView.addJavascriptInterface(new NativeBridge(), "TLMNative");

        boolean openPick = getIntent().getBooleanExtra("open_pick", false);
        webView.loadUrl(openPick ? HOME + "&tab=pick" : HOME);
    }

    public final class NativeBridge {
        @JavascriptInterface
        public String platform() {
            return "android";
        }

        @JavascriptInterface
        public void enableNotifications(String email, String session) {
            pendingEmail = email == null ? "" : email.trim().toLowerCase();
            pendingSession = session == null ? "" : session.trim();

            runOnUiThread(() -> {
                if (pendingEmail.isEmpty() || pendingSession.isEmpty()) {
                    notifyWeb(false, "Connectez-vous avant d'activer les notifications.");
                    return;
                }

                if (
                    Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION
                    );
                    return;
                }

                registerFcmToken();
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(
        int requestCode,
        String[] permissions,
        int[] results
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, results);

        if (requestCode != NOTIFICATION_PERMISSION) return;

        if (
            results.length > 0 &&
            results[0] == PackageManager.PERMISSION_GRANTED
        ) {
            registerFcmToken();
        } else {
            notifyWeb(false, "Permission de notification refusée.");
        }
    }

    private void registerFcmToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null) {
                notifyWeb(false, "Impossible d'obtenir le jeton Firebase.");
                return;
            }

            String token = task.getResult();
            Executors.newSingleThreadExecutor().execute(() -> {
                HttpURLConnection connection = null;

                try {
                    URL endpoint = new URL(
                        "https://www.touslesmatchs.com/api/fcm/register"
                    );

                    connection = (HttpURLConnection) endpoint.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty(
                        "Content-Type",
                        "application/json; charset=utf-8"
                    );

                    JSONObject body = new JSONObject();
                    body.put("email", pendingEmail);
                    body.put("session", pendingSession);
                    body.put("token", token);

                    byte[] bytes = body.toString()
                        .getBytes(StandardCharsets.UTF_8);

                    try (OutputStream output = connection.getOutputStream()) {
                        output.write(bytes);
                    }

                    int status = connection.getResponseCode();

                    if (status >= 200 && status < 300) {
                        notifyWeb(true, "Notifications activées, même application fermée.");
                    } else {
                        notifyWeb(false, "Session ou abonnement non valide.");
                    }
                } catch (Exception error) {
                    notifyWeb(false, "Connexion Firebase impossible.");
                } finally {
                    if (connection != null) connection.disconnect();
                }
            });
        });
    }

    private void notifyWeb(boolean success, String message) {
        String javascript =
            "window.tlmNativeNotificationResult&&" +
            "window.tlmNativeNotificationResult(" +
            (success ? "true" : "false") + "," +
            JSONObject.quote(message) + ");";

        webView.post(() ->
            webView.evaluateJavascript(javascript, null)
        );
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
